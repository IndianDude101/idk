package laksh.graph;

public enum Type {

    Node,
    Edge,
    StartNode,
    EndNode,
    Invalid

}
