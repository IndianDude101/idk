package laksh.graph;public enum Type {
}
