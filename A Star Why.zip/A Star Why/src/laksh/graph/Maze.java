package laksh.graph;

import laksh.Utils;

import java.util.ArrayList;
import java.util.HashMap;

public class Maze {
    private int height, width;
    public  Node[][] maze;
    private HashMap<Node, Node[]> graph = new HashMap();

    public Maze(int width, int height){
        this.width = width;
        this.height = height;

        maze = new Node[height][width];

    }

    public void genMaze(){
        for (int row = 0; row <  height; row++){
            for (int column = 0; column < width; column++){
                Node x = Utils.inputNode();
                x.setIndex(new int[]{row, column});
                maze[row][column] = x;
            }
        }
    }

    public void printMaze(){
        StringBuilder x = new StringBuilder("[");

        for (int row = 0; row <  height; row++){
            x.append("{");
            for (int column = 0; column < width; column++){
                x.append(maze[row][column].getValue()).append(column == width - 1 ? "" : ", ");
            }
            x.append("}").append(row == height - 1 ? "" : "\n");
        }
        x.append("]");
        System.out.println(x.toString());
    }
    public Node[] getFree(Node n){
        return new Node[]{getLeft(n), getRight(n), getUp(n), getDown(n)};
    }


    public Node getLeft(Node n){
        return n.getIndex()[1] - 1 >= 0 ? n.getType() == Type.Node ? maze[n.getIndex()[0]][n.getIndex()[1] - 1] : null : null;
    }
    public Node getRight(Node n){
        return n.getIndex()[1] + 1 >= 0 ? n.getType() == Type.Node ? maze[n.getIndex()[0]][n.getIndex()[1] + 1] : null : null;
    }
    public Node getUp(Node n){
        return n.getIndex()[0] + 1 >= 0 ? n.getType() == Type.Node ? maze[n.getIndex()[0] + 1][n.getIndex()[1]] : null : null;
    }
    public Node getDown(Node n){
        return n.getIndex()[0] - 1 >= 0 ? n.getType() == Type.Node ? maze[n.getIndex()[0] - 1][n.getIndex()[1]] : null : null;
    }



}
