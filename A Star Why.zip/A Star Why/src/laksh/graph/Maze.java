package laksh.graph;

import laksh.Utils;    // 10:58

public class Maze { // Modelled as a graph
    private int height, width;
    private Node[][] maze;

    public Maze(int width, int height){
        this.width = width;
        this.height = height;

        maze = new Node[height][width];

    }

    public void genMaze(){
        for (int row = 0; row <  height; row++){
            for (int column = 0; column < width; column++){
                maze[row][column] = Utils.inputNode();
            }
        }
    }

    public void printMaze(){
        StringBuilder x = new StringBuilder("[");

        for (int row = 0; row <  height; row++){
            x.append("{");
            for (int column = 0; column < width; column++){
                x.append(maze[row][column].getValue()).append(column == width - 1 ? "" : ", ");
            }
            x.append("}").append(row == height - 1 ? "" : "\n");
        }
        x.append("]");
        System.out.println(x.toString());
    }

}
