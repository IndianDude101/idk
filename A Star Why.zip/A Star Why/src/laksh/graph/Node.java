package laksh.graph;

public class Node {
    public Node parent, next;
    private int value;
    private int[] index;
    private Type type;

    public Node(int value){
        this.value = value;
        type = value == 0 ? Type.Node : value == 1 ? Type.Edge : value == 2 ? Type.StartNode : value == 3 ? Type.EndNode : Type.Invalid; // kys java
    }

    public int[] getIndex() {
        return index;
    }

    public void setIndex(int[] index) {
        this.index = index;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
}
