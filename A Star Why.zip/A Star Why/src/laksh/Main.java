package laksh;

import laksh.graph.Maze;

public class Main {

    public static void main(String[] args) {
        Maze x = new Maze(Utils.inputInt("Maze width - "),Utils.inputInt("Maze Height - "));
        x.genMaze();
        x.printMaze();
    }
}
