package laksh;

import laksh.graph.Maze;
import laksh.graph.Node;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        Maze x = new Maze(Utils.inputInt("Maze width - "),Utils.inputInt("Maze Height - "));
        x.genMaze();
        x.printMaze();

        System.out.println(x.getRight(x.maze[0][0]).getValue());
        System.out.println(x.getRight(x.maze[0][0]).getType());
        System.out.println(Arrays.toString(x.getRight(x.maze[0][0]).getIndex()));
        Node y = x.maze[0][0]

        for (Node n : x.getFree(y)){
            System.out.println(n.getType());
        }

    }
}
