package laksh;

import laksh.graph.Node;

import java.util.Scanner;

public class Utils {
    private static Scanner sc = new Scanner(System.in);

    public static int inputInt(String prompt){
        System.out.println(prompt);
        return sc.nextInt();
    }

    public static Node inputNode(){
        return new Node(inputInt("Enter a value"));
    }

}
