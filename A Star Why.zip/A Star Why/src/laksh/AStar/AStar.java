package laksh.AStar;public class AStar {
}
