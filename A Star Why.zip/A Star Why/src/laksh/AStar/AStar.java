package laksh.AStar;

public class AStar {
    public AStar(){

    }


}
